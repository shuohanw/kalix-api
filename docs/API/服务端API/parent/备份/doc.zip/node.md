# node 设置 

## npm 镜像方法，由于网速原因，好多同过npm安装的包包无法正常安装
查看 npm config get registry
设置 npm config set registry  https://registry.npm.taobao.org