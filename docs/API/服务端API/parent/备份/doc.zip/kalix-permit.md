# kalix 权限技术文档

## shiro 配置