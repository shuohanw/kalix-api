# kalix 业务服务

## attachment 服务
> 提供附件的上传下载功能

## excel 服务
> 提供excel格式的导出

## workflow 服务
> 提供对工作流引擎Activiti的封装