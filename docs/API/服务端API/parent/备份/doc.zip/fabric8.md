## doc
https://fabric8.io/guide/karaf.html
## f8 maven plugin
https://maven.fabric8.io/

## f8 karaf image
https://hub.docker.com/r/fabric8/s2i-karaf/

